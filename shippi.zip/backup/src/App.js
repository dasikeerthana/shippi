// import './App.css';
import Login from './screens/Login';
import Admin from './screens/Admin';
import Employee from './screens/Emp';
import Order from './screens/Ord';
import Ordlist from './screens/Ordlist';
import EmpRec from './screens/EmpRec';
import AddEmp from './screens/AddEmp';
import Status from './screens/Status';
import Cost from './screens/Cost';
import React, { Component } from 'react';

class App extends Component {
  state={
    page:"Login"
  }

  pageChange=(page)=>{
    console.log("arrived ", page);
   this.setState({page:page});
  }

  getPageToShow=()=>{
    if(this.state.page==="Login")
      return (<Login pageChange={this.pageChange}/>)
    else if (this.state.page ==="Admin")
    {
      return (<Admin  pageChange={this.pageChange}/>)
    }
    else if (this.state.page ==="Employee")
    {
      return (<Employee  pageChange={this.pageChange}/>)
    }
    else if (this.state.page ==="Order")
    {
      return (<Order  pageChange={this.pageChange}/>)
    }
    else if (this.state.page ==="Ordlist")
    {
      return (<Ordlist  pageChange={this.pageChange}/>)
    }
    else if (this.state.page ==="EmpRec")
    {
      return (<EmpRec  pageChange={this.pageChange}/>)
    }
    else if (this.state.page ==="AddEmp")
    {
      return (<AddEmp  pageChange={this.pageChange}/>)
    }
    else if (this.state.page ==="Status")
    {
      return (<Status  pageChange={this.pageChange}/>)
    }
    else if (this.state.page ==="Cost")
    {
      return (<Cost  pageChange={this.pageChange}/>)
    }
    
    
  }
  render(){
    let pageToShow=this.getPageToShow();
    return (
    <div style={{flex:1}}>
     {pageToShow}
    </div>
  );
  }
}

export default App;
