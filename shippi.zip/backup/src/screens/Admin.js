import React, { Component } from 'react';
import imag from './bcimg.jpg'
export default class Admin extends Component {
    gotoNextPage=(pageName)=>{
        if (pageName==='o'){
            this.props.pageChange("Ordlist")
        }
        else if (pageName==='e'){
            this.props.pageChange("EmpRec")
        }
        else if (pageName==='a'){
            this.props.pageChange("AddEmp")
        }
        else if (pageName==='login'){
            this.props.pageChange("Login")
        }
    }
    render() {
        return (
            <>
            <div style={{ backgroundImage:`url(${imag})`,height:'10000px' }}>
                <h1 style={{ "padding": "15px",'fontFamily':"georgia","fontSize":"25px" }}>Admin operations</h1>
                <br />
                    <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value=" Order records "  onClick={()=>{this.gotoNextPage("o")}}/> <br /><br />
                    <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value=" Employee records " onClick={()=>{this.gotoNextPage("e")}}/> <br /><br />
                    <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value=" Add Employee " onClick={()=>{this.gotoNextPage("a")}}/><br/><br/>
                        <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value=" Log Out " onClick={()=>{this.gotoNextPage('login')}}/>
                </div>
            </>
        );
    }
            }