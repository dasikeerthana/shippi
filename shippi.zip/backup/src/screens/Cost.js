import React, { Component } from 'react';
import imag from './bcimg.jpg'
export default class Login extends Component {
    
    state={
        proceed:false,
        cashless:false,
        done:false,
        estimation:false
    };

    
    componentDidMount=async () =>{
        await this.getCost();
    }
    getCost = async () => {
        let response = await fetch("http://localhost:9000/Cost  ", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({

                "pay": 'data'
            }),

        }).then(res => {
            return res.json()
        });
        this.setState({estimation:response})

            // this.state.estimation = response;
        }


    submit = async () => {
        let transactionID;
        let pay = document.getElementById("service").value;
        if(pay==="Cashless"){
            
            transactionID = document.getElementById("transactionID").value;
        }
        else{
            transactionID="Cash";
        }
        let response = await fetch("http://localhost:9000/Cost", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({

                "pay": transactionID
            }),

        }).then(res => {
            return res.json()
        });
        console.log(" retured the reponse:", response);
        if(response==="Done"){
            this.setState({done:true}); 
        }
        
    }

    setProceed=()=>{ 
        this.setState({proceed:true});
    }
    cancel=()=>{
        this.props.pageChange("Employee");
    }
    setcashless=()=>{
        console.log("it is cashless");
        this.setState({cashless:true});
    }
     render() {
         
        
        return (
            <>
                <div style={{ backgroundImage:`url(${imag})`,height:"1500px"}}>
                    <br />
                    {this.state.estimation && (<><p style={{"padding":'5px',"fontSize":'25px',"fontFamily":'georgia'}}>Delivery charges for the consignment are: </p><br></br>
                    <p style={{"padding":'5px',"fontSize":'20px',"fontFamily":'georgia'}}>      Shipping charges : Rs.{this.state.estimation['data']['cost']} </p>
                     
                    <p style={{"padding":'5px',"fontSize":'20px',"fontFamily":'georgia'}}>                 Taxes : Rs.{this.state.estimation['data']['gst']} </p>
                     
                    <p style={{"padding":'5px',"fontSize":'20px',"fontFamily":'georgia'}}>Total amount to be paid :  Rs.{this.state.estimation['data']['total']}</p>
                    
                    <p style={{"padding":'5px',"fontSize":'20px',"fontFamily":'georgia'}}>Estimated delivery date is  {this.state.estimation['data']['date']}</p>
                    <p>Do you want to proceed with the order</p>  </>)}
                   
                    <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value="cancel" onClick={this.cancel} />
                    <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="submit" value="Proceed" onClick={this.setProceed} /><br></br>
                    <br></br>
                   {this.state.proceed && (<><label style={{"padding":'7px'}} for="service"> Choose a Payment mode : </label>
                   <br/>
                    <select style={{"margin":'7px'}} id="service" name="service" required>
                    <option value="Cash">Cash</option>
                    <option value="Cashless" onClick={this.setcashless}>Cashless</option>
                    </select><br></br></>
                   )}
                   
                   {this.state.cashless &&(<><label for="transactionID"> Transaction ID :</label>
                    <input  type="text" id="transactionID" name="transactionID" /></>)}
                   
                    <br/>
                   {this.state.proceed && (<input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}}  type="submit" value="Submit" onClick={()=>{this.submit()}} />)}
                    {this.state.done && (<p style={{"color":'green'}}>Your order has been placed sucessfully </p>)}
                </div>
            </>
        );
    }
}