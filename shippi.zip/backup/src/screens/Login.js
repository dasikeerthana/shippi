import React, { Component } from 'react';
import imag from './bimg.jpg'
export default class Login extends Component {

    state = {
        areCredValid: true
    };
    

    popup = async () => {
        let username = document.getElementById("uname").value;
        let password = document.getElementById("pword").value;
        let response = await fetch("http://localhost:9000/login", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "username": username,
                "password": password
            }),

        }).then(res => {
            return res.json()
        });
        console.log(" retured the reponse:", response);
        if (response === "ValidA") {
            this.props.pageChange("Admin");
        }
        else if (response === "ValidE") {
            this.props.pageChange("Employee");
        }
        else {
            this.setState({ areCredValid: false });
        }
    }

    render() {
        console.log( " the url is ", JSON.stringify(process.env));
        return (
            <body>
                <div   style={{ backgroundImage:`url(${imag})`, width: "1000px", height: "600px"}}>
                    <br />
                    <h2 style={{ "padding": "10px",'fontFamily':"georgia","fontSize":"25px" }}>Login</h2>
                    <p />
                    {/* <form id="LoginForm" style={{"padding-right": "500px"}}> */}
                    <label for="uname" style={{ "padding": "5px" }}> Username :</label>
                    <br />
                    <input style={{"margin":'4px'}} type="text" id="uname" name="uname" required/>
                    <br />
                    <label for="pword" style={{ "padding": "5px" }}> Password :</label>
                    <br />
                    <input style={{"margin":'4px'}} type="password" id="pword" name="pword" required/><br /><br />
                    <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="submit" value="Submit" onClick={this.popup} />
                    {!this.state.areCredValid && (<h3 style={{ color: "red" }}>Invalid credentials</h3>)}
                    {/* </form> */}
                    {/* <button  type="button" name="submit22" onClick={this.buttonClicked}>Button</button> */}
                </div>
            </body>
        );
    }
}