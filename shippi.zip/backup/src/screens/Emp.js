import React, { Component } from 'react';
import imag from './bcimg.jpg'
export default class Employee extends Component {
    gotoNextPage=(pageName)=>{
        if (pageName==='n'){
            this.props.pageChange("Order")
        }
        else if (pageName==='s'){
            this.props.pageChange("Status")
        }
        else if (pageName==='login'){
            this.props.pageChange("Login")
        }
    }

    render() {
        return (
            <>
            <div style={{  backgroundImage:`url(${imag})`,width: "1500px", height: "1000px" ,"backgroundColor":'beige' }}>
 <p style={{"padding":'25px',"fontFamily":"georgia","fontSize":"25px"}}>Employee operations</p>
              <br/>
                    <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value=" New order" onClick={()=>{this.gotoNextPage('n')}} /> <br/><br/>
                        <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value=" Status update " onClick={()=>{this.gotoNextPage('s')}} /><br/><br/>
                        <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value=" Log Out " onClick={()=>{this.gotoNextPage('login')}} />
    
      </div>
               
            </>
        );
    }
}
