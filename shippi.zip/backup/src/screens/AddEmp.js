import React, { Component } from 'react';
import imag from './bcimg.jpg'
export default class Order extends Component {
    previousPage=async()=>{
        this.props.pageChange("Admin");
    }
    popup = async () => {
        let name = document.getElementById("name").value;
        let phone = document.getElementById("pnum").value;
        let mail = document.getElementById("mail").value;
        let designation = document.getElementById("desg").value;
        let address = document.getElementById("addr").value;
        let salary = document.getElementById("salary").value;
        let uname = document.getElementById("uname").value;
        let pword = document.getElementById("pword").value;
        
        let response = await fetch("http://localhost:9000/AddEmp", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "name": name,
                "phone": phone,
                "mail":mail,
                "designation":designation,
                "postalAddress":address,
                "salary":salary,
                'username':uname,
                'password':pword
            }),

        }).then(res => {
            return res.json()
        });
        console.log(" retured the reponse:", response);
            this.props.pageChange("AddEmp");
        
    }

render() {
    return (
        <>
             <div style={{ backgroundImage:`url(${imag})`,  width:"1500px", height:"1000px" ,"backgroundColor":'beige'}}>
             <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}}  type="button"  value=" Back " onClick={this.previousPage}/>
        
<h1 style={{"font-family":"monaco","fontSize":'25px',"padding":'9px'}}>New Employee </h1>

     <label style={{"padding":'8px',"fontFamily":'serif'}}style={{"padding":'8px',"fontFamily":'serif'}}   for="name"> Name :</label><br/>
    <input style={{"margin":'4px'}}  type="text" id="name" name="name" required/><br/><br/>
    <label style={{"padding":'8px',"fontFamily":'serif'}} for="pnum"> Phone Number :</label><br/>
    <input style={{"margin":'4px'}}  type="tel" id="pnum" name="pnum" pattern="[0-9]{10}" />   
    <br/><br/>
    <label style={{"padding":'8px',"fontFamily":'serif'}} for="mail"> Email :</label><br/>
    <input style={{"margin":'4px'}} type="email" id="mail" name="mail" required/><br/><br/>
    <label style={{"padding":'8px',"fontFamily":'serif'}} for="addr"> Address :</label><br/>
    <input style={{"margin":'4px'}} type="text" id="addr" name="addr" required/><br/><br/>
    <label style={{"padding":'8px',"fontFamily":'serif'}} for="desg"> Designation :</label><br/>
    <input style={{"margin":'4px'}} type="text" id="desg" name="desg" required/><br/><br/>
    <label style={{"padding":'8px',"fontFamily":'serif'}} for="salary"> Salary :</label><br/>
    <input style={{"margin":'4px'}} type="tel" id="salary" name="salary" required/>  <br/><br/>
    <label style={{"padding":'8px',"fontFamily":'serif'}} for="uname"> Username :</label><br/>
    <input style={{"margin":'4px'}} type="txt" id="uname" name="uname" required/>   <br/><br/>
    <label style={{"padding":'8px',"fontFamily":'serif'}} for="pword"> Password :</label><br/>
    <input style={{"margin":'4px'}} type="text" id="pword" name="pword" required/><br/><br/>
    <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button"  value="Add Employee"  onClick={this.popup}/><br/><br/>
    

</div>
      
            </>
        );
    }
}

