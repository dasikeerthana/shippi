import React, { Component } from 'react';
import imag from './bcimg.jpg'
export default class 
Order extends Component {
    previousPage=async()=>{
        this.props.pageChange("Employee");
    }
    popup = async() => {
        let name = document.getElementById("name").value;
        console.log("name in orders", name);
        let phone = document.getElementById("pnum").value;
        let mail = document.getElementById("mail").value;
        let service = document.getElementById("service").value;
        let weight = document.getElementById("wght").value;
        let pickupAddress = document.getElementById("paddr").value;
        let destAddress = document.getElementById("daddr").value;
        let destPin = document.getElementById("dpin").value;
        let pickupPin = document.getElementById("spin").value;
        let response = await fetch("http://localhost:9000/Order", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "name": name,
                "phone": phone,
                "mail":mail,
                 "service":service,
                 "weight": Number (weight),
                 "pickupAddress":pickupAddress,
                 "destAddress":destAddress,
                 "destPin":destPin,
                 "pickupPin":pickupPin
            }),

        }).then(res => {
            return res.json()
        });
        console.log(" the response in order.js is ",JSON.stringify(response));
        
            this.props.pageChange("Cost");
        
    }

    render() {
        return (
            <><div style={{ backgroundImage:`url(${imag})`, "backgroundColour":'beige'}} >
             <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button"  value=" Back " onClick={this.previousPage}/>
                 
    <h1>Order</h1>
    
    {/* <form> */}
        <label style={{"padding":'7px'}}  for="name"> Name :</label><br/>
        <input  style={{"margin":'4px'}} type="text" id="name" name="name" required/><br/><br/>
         <label style={{"padding":'7px'}} for="pnum"> Phone Number :</label><br/>
        <input style={{"margin":'4px'}} type="tel" id="pnum" name="pnum" pattern="[0-9]{3}" required/><br/><br/> 
        
        <label style={{"padding":'7px'}} for="mail"> Email :</label><br/>
        <input style={{"margin":'4px'}} type="email" id="mail" name="mail" required/><br/><br/>
       

        <label style={{"padding":'7px'}} for="service">Choose a service : </label><br/>
  <select style={{"margin":'4px'}} id="service" name="service" required>
    <option value={"Fast shipping"}>Fast shipping</option>
    <option value={"Regular shipping"}>Regular shipping</option>
    <option value={"Express shipping"}>Express shipping</option>

  </select>
  <br/><br/>

        <label style={{"padding":'7px'}} for="wght"> Weight of consignment :</label><br/>
        <input style={{"margin":'4px'}} type="tel" id="wght" name="wght" required/ ><br/><br/>
        
        <label style={{"padding":'7px'}} for="paddr"> pickup address :</label><br/>
        <input style={{"margin":'4px'}} type="text" id="paddr" name="paddr"required/><br/><br/>

        <label style={{"padding":'7px'}} for="spin"> source pincode :</label><br/>
        <input style={{"margin":'4px'}} type="tel" id="spin" name="spin" required/><br/><br/>

        <label style={{"padding":'7px'}} for="daddr"> delivery address :</label><br/>
        <input style={{"margin":'4px'}} type="text" id="daddr" name="daddr" required/><br/><br/>

        <label style={{"padding":'7px'}} for="dpin"> destination pincode :</label><br/>
        <input style={{"margin":'4px'}} type="tel" id="dpin" name="dpin" required/><br/><br/> 
        
    

        <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value=" Proceed " onClick={()=>{this.popup()}}/>
        {/* </form>  */}

</div>
      
            </>
        );
    }
}