import React, { Component } from 'react';
import imag from './bcimg.jpg'
export default class Order extends Component {
   
   state = { orderinfo: [] }

   previousPage=async()=>{
      this.props.pageChange("Admin");
  }

  componentDidMount = async () => {
   await this.data();

}

data = async () => {
   let response = await fetch("http://localhost:9000/Ordlist", {
       method: "GET",
       headers: {
           'Content-Type': 'application/json'
       }, }).then(res => {
           return res.json()
       });
       console.log(" the response is ", JSON.stringify(response));
   this.setState({ orderinfo: response.data });
}
    render() {
      // await this.data();
      return (
       <body> 
          <div style={{   backgroundImage:`url(${imag})`, width: "1500px", height: "1000px" ,"backgroundColor":'beige'}}>
<br/>
           <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button"  value=" Back " onClick={this.previousPage}/> <br/><br/>
            <table style={{ 'border': '1px solid black', "borderColor": 'steelblue', borderWidth:'2px' }}>
         <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Destination Address</th>
            <th>Destination Pincode</th>
            <th>Source Address</th>
            <th>Source Pincode</th>
            <th>Weight</th>
            <th>Service</th>
            <th>Status</th>
            <th>Cost</th>
            <th>Payment</th>
         </tr>
        
                        {this.state.orderinfo && this.state.orderinfo.length > 0 && this.state.orderinfo.map(row => {
                          return ( <tr>
                           {row.map(cell =>{return (<td style={{"width":"500px"}}>{cell}</td>)})}
                            </tr>)
                        })}
      </table>
      </div></body>
      
      
   );
   }
}