import React, { Component } from 'react';
import imag from './bcimg.jpg'
export default class Order extends Component {
    state={
        valid:false,
        done:false
    };
    state = { orderinfo: [] }
    
    previousPage=async()=>{
        this.props.pageChange("Employee");
    }
    
    
    status=async() =>{
        let status = document.getElementById("status").value;
        let response = await fetch("http://localhost:9000/Status", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "ID":this.orderInfo[0],
                "status": status,
                "phone":this.orderInfo[2]  }),

        }).then(res => {
            return res.json()
        });
        console.log(" retured the reponse:", response);
       
        if (response === "Done") { 
            this.setState({done:true});
        }
    
    }
    
    
    page = async () => {
        let ordID = document.getElementById("ordID").value;
        let response = await fetch("http://localhost:9000/Status", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({

                "ID": ordID
            }),

        }).then(res => {
            return res.json()
        });
        console.log(" retured the reponse:", response.data); 
        this.orderInfo = response.data;
        console.log(this.orderInfo); 
        this.setState({valid:true}); }

    
    render() {
      return (
          <>
          <div style={{   backgroundImage:`url(${imag})`, width: "1000px", height: "1000px","backgroundColor":'beige' }}>
          <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button"  value=" Back " onClick={this.previousPage}/>
          <h1 style={{"font-family":"georgia","fontSize":'25px',"padding":'7px'}}>Status Update</h1>
        
        <label style={{"padding":'3px'}} for="ordID"> Enter the order ID :</label>
        
        <input type="text" id="ordID" name="ordID" required />
        <input style={{"borderRadius":"2px","backgroundColor":'black',"color":"white","margin":'7px'}} type="button" value="search" onClick={this.page} />
        
  
        <br></br>
    
         {this.state.valid &&  (<>
         <br></br>
                    <label for="status">status </label> 

    <select id="status" name="status" value={this.orderInfo[10]}  onClick={this.status} required>
    <option value="Ready to ship">Ready to ship</option>
    <option value="In transit">In transit</option> 
    <option value="Out for delivery">Out for delivery</option>

  </select>
  <br></br><br></br>
   <input type="button" value="Update" onClick={this.status}/> </>)


            }
        {this.state.done && (<p>The status of the consignment has been updated </p>)}
        </div> </>
        );
   }}
