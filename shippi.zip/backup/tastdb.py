from flask import Flask,json,jsonify
import sqlite3

   # with sqlite3.connect("database.db") as con:
#    cur=con.cursor();
#    cur.execute('''CREATE TABLE Orders
#          (ID  INT  PRIMARY KEY,
#          NAME           TEXT    NOT NULL,
#          PHONE            INT   ,
#          EMAIL          TEXT ,
#          DESTINATION_ADDRESS        CHAR(50),
#          DESTINATION_PINCODE         REAL,
#          SOURCE_ADDRESS        CHAR(50),
#          SOURCE_PINCODE         REAL,
#          WEIGHT INT,
#           SERVICE TEXT,
#          STATUS TEXT,
#          COST INT,
#          PAYMENT TEXT
#          );''')
#    con.commit()
# with sqlite3.connect("employee.db") as conemp:
#    curemp = conemp.cursor()
#    curemp.execute('''CREATE TABLE Employee
#     (ID INT PRIMARY KEY    AUTOINCREMENT,
#     NAME           TEXT    NOT NULL,
#     PHONE            INT     NOT NULL,
#     EMAIL          TEXT NOT NULL,
#     POSTAL_ADDRESS        CHAR(50),
#     DESIGNATION        CHAR(50),
#     SALARY INT,
#     USERNAME TEXT,
#     PASSWORD TEXT
#     );''')
#    conemp.commit()

if __name__ == '__main__':
        # con=sqlite3.connect('Order.db')
        # cur=con.cursor();
        # cur.execute("INSERT INTO Orders (ID,NAME,PHONE,EMAIL,DESTINATION_ADDRESS,SOURCE_ADDRESS,SOURCE_PINCODE,DESTINATION_PINCODE,WEIGHT,SERVICE,STATUS,COST,PAYMENT) \
        # VALUES ('macpqst@11j10','sarah',7654234789,'sarahparker@gmail.com','churchil road','beach road',518402,500089,30,'express shipping','confirmed',300000,'cash')");
        # cur.execute("select * from orders")
        # print(cur.fetchall())
        # con.commit();
        a=1
        b={}
        conemp=sqlite3.connect('Order.db')
        curemp = conemp.cursor()
         # curemp.execute("INSERT INTO Employee (ID,NAME,PHONE,EMAIL,POSTAL_ADDRESS,DESIGNATION,SALARY,USERNAME,PASSWORD) VALUES (3,'Sarah',7821345608,'Sarah@gmail.com','wisconsin,st.barbara','Admin',500000,'Sarah','password')");
        curemp.execute("Update  Orders set cost='1032' where name=='Jim'")
        rows=curemp.fetchall();

        print( rows )
        conemp.commit();