from flask import Flask, json
from flask import request, jsonify
from datetime import datetime,timedelta,date
import sqlite3
from twilio.rest import Client
import uuid
import pgeocode 

# venv\scripts\activate

def  textmsg(ID,phone_number,status):
     phone='+91'+str(phone_number)
     now=datetime.now()
     a='94e900445aea5bf70edf66f32b7b04b6'
     today=now.strftime("%d/%m/%Y %H:%M:%S")
     account_sid = 'AC08199f90ff0f47f875abe87cd0aee9ff'
     auth_token = '94e900445aea5bf70edf66f32b7b04b6'
     client = Client(account_sid, auth_token)
     message = client.messages.create(body=today+'\nThis is to notify you that your consignment with the ID '+ID+ '  is '+status+' \nShipEx', from_='+13026637098', to=phone)

     print("the message is ",message)

pending={}
estimation={}
app = Flask(__name__)




app.route('/AddEmp' ,methods=[ 'POST'])
def addEmp():
   obj=json.loads(json.dumps(request.get_json(force=True)))
   conemp=sqlite3.connect("Employee.db")
   curemp = conemp.cursor() 
   id = uuid.uuid1().hex
   print(id)
   curemp.execute("INSERT INTO COMPANY (ID,NAME,PHONE,EMAIL,POSTAL ADDRESS,DESIGNATION,SALARY) VALUES (?,?,?,?,?,?,?)",(id,obj["name"],obj['phone'],obj['email'],obj['postalAddress'],obj['designation'],obj['salary']));
   conemp.commit()
   return jsonify("Done");
      
      

@app.route('/Ordlist')
def Ordlist():
   con=sqlite3.connect('Order.db')
   cur = con.cursor()
   cur.execute("select * from Orders")
   
   rows = cur.fetchall(); 
   dict={}
   dict['data']=rows
   return jsonify(dict)
    

@app.route('/Cost' ,methods=[ 'POST'])
def cost():
   global estimation
   print( "the value in estimation",estimation )
   dict={}
   pay=json.loads(json.dumps(request.get_json(force=True)))
   if pay['pay']=='data':
      dict['data']=estimation
      return jsonify(dict)
   else:  
      obj=pending
      print(" data in pending", pending);
      con=sqlite3.connect('Order.db')   
      cur = con.cursor()
      id = uuid.uuid1().hex
      
      cur.execute("INSERT INTO Orders (ID,NAME,PHONE,EMAIL,DESTINATION_ADDRESS,SOURCE_ADDRESS,SOURCE_PINCODE,DESTINATION_PINCODE,WEIGHT,SERVICE,STATUS,COST,PAYMENT) \
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",(id,obj['name'],obj['phone'],obj['mail'],obj['destAddress'],obj['pickupAddress'],obj['pickupPin'],obj['destPin'],obj['weight'],obj['service'],'confirmed',estimation["cost"],pay['pay']));
      con.commit()
     
      textmsg(id,obj['phone'],'confirmed')   
      return jsonify("Done");
      

@app.route('/EmpRec' ,methods=[ 'GET'])
def EmpRec():
   conemp=sqlite3.connect("Employee.db")
   curemp=conemp.cursor();
   curemp.execute("select * from Employee")
   
   rows = curemp.fetchall(); 
   dict={}
   dict['data']=rows
   return jsonify(dict)


@app.route('/Status' ,methods=[ 'POST'])
def Status():
   obj=json.loads(json.dumps(request.get_json(force=True)))
   print(type(obj),obj);
   con=sqlite3.connect('Order.db')
   cur=con.cursor();
   if len(obj)==1:
      
      cur.execute("select * from Orders where ID==? ",(obj['ID'],))
      rows=cur.fetchall()
      dict={}
      dict['data']=rows
      print(rows)
      return jsonify(dict)
   else:
      cur.execute("UPDATE Orders SET status = ? WHERE ID == ?;",(obj['status'],obj['ID']))
      textmsg(obj['ID'],obj['phone'],obj['status'])
      return jsonify("Done")

@app.route('/Order' ,methods=[ 'POST'])
def Order():
   global pending,cost
   print( "before",pending )
   obj=json.loads(json.dumps(request.get_json(force=True)))
   pending=obj;
   print(pending)
   dist = pgeocode.GeoDistance('IN')
   distance=dist.query_postal_code(str(obj['destPin']),str(obj['pickupPin']))
   print("geo distance is", distance);
   hrs=distance/(60*24)
   if  hrs-int(hrs)>0:
      hrs=hrs+1
   Begindate = date.today()
   cost=0

   if obj['service']=='Fast shipping':
      estimation['date']=Begindate + timedelta(days=(hrs+2))
      estimation['date']=estimation['date'].strftime("%x")
      cost=obj['weight']*3
      if obj['weight'] > 20:
         cost=(distance/100)*40+cost
      if obj['weight'] > 16:
         cost=(distance/100)*30+cost
      if obj['weight'] > 10:
         cost=(distance/100)*20+cost
      if obj['weight'] > 6:
         cost=(distance/100)*15+cost
      if obj['weight'] > 2:
         cost=(distance/100)*10+cost
      cost=cost+(distance/100)*70
   if obj['service']=='Regular shipping':
      estimation['date']=Begindate + timedelta(days=(hrs+4))
      estimation['date']=estimation['date'].strftime("%x")
      cost=obj['weight']*2
      if obj['weight'] > 20:
         cost=(distance/100)*30+cost
      if obj['weight'] > 16:
         cost=(distance/100)*20+cost
      if obj['weight'] > 10:
         cost=(distance/100)*17+cost
      if obj['weight'] > 6:
         cost=(distance/100)*10+cost
      if obj['weight'] > 2:
         cost=(distance/100)*7+cost
      cost=cost+(distance/100)*600

   if obj['service']=='Express shipping':   
      estimation['date']=Begindate + timedelta(days=(hrs+1))
      estimation['date']=estimation['date'].strftime("%x")
      cost=obj['weight']*5
      if obj['weight'] > 20:
         cost=(distance/100)*43+cost
      if obj['weight'] > 16:
         cost=(distance/100)*33+cost
      if obj['weight'] > 10:
         cost=(distance/100)*23+cost
      if obj['weight'] > 6:
         cost=(distance/100)*17+cost
      if obj['weight'] > 2:
         cost=(distance/100)*13+cost
      cost=cost+(distance/100)*80
      cost=int(cost)
   estimation['gst']=(cost*18)//100
   estimation['cost']=cost//1
   estimation['total']=(cost+estimation['gst'])//1
   
   return jsonify("Valid")
   
      
      

@app.route('/login' ,methods=[ 'POST'])
def login():
      obj=json.loads(json.dumps(request.get_json(force=True)))
      con=sqlite3.connect('Employee.db')
      cur=con.cursor()
      cur.execute("select * from Employee where USERNAME==? AND PASSWORD==?",(obj['username'],obj['password']))
      rows=cur.fetchall();
      print( "ros are",rows )
      if len(rows)==0:
         return jsonify("InValid");
      elif rows[0][5]=="Admin": 
         return jsonify("ValidA");
      elif rows[0][5]=="Employee":
         return jsonify("ValidE");
      

if __name__ == '__main__':
   app.run(host="127.0.0.1",port=9000, debug=True)