
from socket import *
import re

def compute(input1, input2):
    print( "input1 is:"+input1+" input2 is:"+input2)

def createServer():
    #create a socket stream to communicate with ipv2(af_inet)
    serversocket = socket(AF_INET, SOCK_STREAM)
    try :
        serversocket.bind(('localhost',9000))
        serversocket.listen(5)
        f = open("helloworld.html","r")
        homePage = f.read()
        f= open("output.html", "r");
        outputPage = f.read();
        # print(homePage)
        while(1):
            (clientsocket, address) = serversocket.accept()

            rd = clientsocket.recv(5000).decode()
            responce = homePage
            # if "sendingInputs" in rd:
            print( rd );
            responce = "{'ac' : 'Received the inputs'}"
            # matches = re.match(r'^.*input1\=(\w+)&input2\=(\w+)', rd);
            # compute(matches.groups()[0], matches.groups()[1])
            # pieces = rd.split("\n")
            # if ( len(pieces) > 0 ) : print(pieces[0])
            clientsocket.sendall(responce.encode())
            clientsocket.shutdown(SHUT_WR)

    except KeyboardInterrupt :
        print("\nShutting down...\n");
    except Exception as exc :
        print("Error:\n");
        print(exc)

    serversocket.close()

print('Access http://localhost:9000')
createServer()
